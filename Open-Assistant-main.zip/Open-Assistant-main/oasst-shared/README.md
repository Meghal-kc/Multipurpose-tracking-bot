# Shared Python code for Open Assisstant

Run `pip install -e .` to install the package in editable mode.
