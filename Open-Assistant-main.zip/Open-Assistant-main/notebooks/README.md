# Notebooks

This is a folders with some useful notebooks, all the notebooks have a markdown
file with the same name explaining what they do.

## Contributing

Contributing to both notebooks and making new notebooks is very welcome. If you
do so, make sure to make a markdown (.md) file to go with your notebook, makes
it easier for people to know what your notebook is about.
