# Essay Instructions

Essay Instructions is a notebook that takes an essay as an input and generates
instructions on how to generate that essay. This will be very useful for data
collecting for the model

## Contributing

Feel free to contribute to this notebook, it's nowhere near perfect but it's a
good start. If you want to contribute finding a new model that better suits this
task would be great. Hugginface has a lot of models that could help.
