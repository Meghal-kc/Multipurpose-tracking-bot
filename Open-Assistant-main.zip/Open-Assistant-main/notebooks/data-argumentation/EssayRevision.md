# Essay Revision

Essay Revision is a notebook that generates data for improving essays. It does
that by taking a "good" essay, making it worse step by step and the finding
instructions for making it better. This will be useful for generating data for
the model.

## Contributing

Feel free to contribute to this notebook. It's not perfect but it is quite good.
Finding a better way to make grammatical errors may be a good place to start.
