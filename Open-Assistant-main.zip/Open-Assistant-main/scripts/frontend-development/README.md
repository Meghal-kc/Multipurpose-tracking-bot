# Frontend Development Setup

In root directory run
`docker compose up frontend-dev --build --attach-dependencies` to start a
database and the backend server.

Then, point your frontend at `http://localhost:8080` to start developing. During
development, any API key will be accepted.
