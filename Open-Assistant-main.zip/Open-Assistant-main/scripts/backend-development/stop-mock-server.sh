#!/usr/bin/env bash

docker stop oasst-mock-backend
