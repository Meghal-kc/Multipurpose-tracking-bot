import typer

def main(output_dir: str = "data"):
    """Download and prepare the dataset for use."""
    raise NotImplementedError

if __name__ == "__main__":
    typer.run(main)