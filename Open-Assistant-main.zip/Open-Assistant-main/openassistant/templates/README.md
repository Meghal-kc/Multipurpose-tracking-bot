# Dataset preparation instructions for {dataset_name}

## Setup

Add any installation details here.

## Usage

Explain how to run any scripts that involve preparing local dataset files, e.g.
if the dataset files aren't public or are produced by a web scraper.
