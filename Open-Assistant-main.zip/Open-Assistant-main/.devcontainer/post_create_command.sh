# ensure pre-commit is installed
pre-commit install
