export const colors = {
  light: {
    bg: "rgb(250,250,250)",
    text: "black",
  },
  dark: {
    bg: "gray.900",
    text: "white",
  },
  "dark-blue-btn": {
    200: "rgb(29,78,216)",
    300: "blue",
  },
};
