1. No small spelling changes (unless you are already a contributor)
> This is to keep contributors seen as a respected role, which you get from helping DMDGO, not correcting the spelling.

2. Additions must not interrupt the flow of the average user.
> Don't add things which would interrupt the average Mass DMer.

3. Additions must be relevent to mass dming.
> Features like raiding aren't relevent to DMDGO's core purpose, so they shouldn't be added.

4. Explain how your pull request will improve the program.
> It helps me be able to review and understand your PR easier.
