## Checklist:

- [ ] My pull request doesn't just contain spelling corrections.
- [ ] My pull request doesn't interrupt the flow of the average user.
- [ ] My pull request is relevent to Mass DMing.
- [ ] I have explained how my pull request will improve the program.

(replace the spaces with an `x` to tick it)

## Changes made:

(explain what changes you have made to DMDGO)

## Why I've done these changes:

(how does this improve DMDGO)
