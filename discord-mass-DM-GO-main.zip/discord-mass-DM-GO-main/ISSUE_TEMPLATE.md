### Put the following in the title of your Issue:

`[Question]` for a general question.
> Be specific, people can't help you if we don't know what you are talking about

`[Bug]` for unexpected error/behavior on the program.
> Please include your:
> - DMDGO version (shown on title screen)
> - Whether you built from source or downloaded a release
> - Your operating system.


## Explain your question/bug below:


